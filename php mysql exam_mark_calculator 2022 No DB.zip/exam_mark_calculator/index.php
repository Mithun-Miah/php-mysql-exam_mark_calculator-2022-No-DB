<?php

$connect = mysqli_connect('localhost','root', '','exam');
if($connect){
    // echo "done";
}else{
    echo "fail";
}

if(isset($_POST['send'])){
    $name = $_POST['name'];
    $roll = $_POST['roll'];

    $bangla = $_POST['bangla'];
    $english = $_POST['english'];
    $math = $_POST['math'];
    $php = $_POST['php'];

    

    if($name=="" || $roll=="" || $bangla=="" || $english=="" || $math=="" || $php==""){
        echo "<script>alert('Please Fillup All Fields')</script>";
    }else{
        $total = $bangla + $english + $math + $php;
    $ave = $total/4;
        
        if($ave>80 && $ave<100){
            $grade = "A+";
        }elseif($ave>60 && $ave<79){
            $grade = "A";
        }elseif($ave>40 && $ave<59){
            $grade = "B";
        }elseif($ave>33 && $ave<39){
            $grade = "C";
        }elseif($ave<33){
            $grade = "Failed";
        }else{
            $grade = "Invalid";
        }
    
        $insert = "INSERT INTO calculator(name,roll,bangla,english,math,php,total,average,grade) 
        VALUES('$name','$roll','$bangla','$english','$math','$php','$total','$ave','$grade')";
    
        $query = mysqli_query($connect,$insert);
        if($query){
            //echo "Data Send Success";
            echo "<script>alert('Data Send Success')</script>";
        }else{
            //echo "Data Send Failed";
            echo "<script>alert('Data Send Failed')</script>";
        }
        
    }

    
    
    
    
    
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Exam Mark Calculator</title>

    <style>
    .container {
        width: 700px;
        background-color: brown;
        padding: 20px;
        margin: auto;
        box-shadow: 2px 2px 10px;
    }

    h1 {
        color: white;
        text-align: center;
    }

    input {
        width: 90%;
        border: none;
        border-radius: 10px;
        padding: 20px;
        font-size: 1.1rem;
    }

    button {
        border: none;
        font-size: 1.4rem;
        font-weight: 700;
        border-radius: 10px;
        padding: 20px;
        width: 50%;
        background-color: green;
        cursor: pointer;
        transition: 0.3s;
    }

    button:hover {
        background-color: blue;
        color: white;
    }
    </style>
</head>

<body>

    <div class="container">
        <h1>Exam Mark Calculator PHP + Mysql</h1>
        <form action="" method="POST">
            <input type="text" name="name" placeholder="enter name"><br><br>
            <input type="text" name="roll" placeholder="roll number"><br><br>
            <input type="text" name="bangla" placeholder="entre bangla"><br><br>
            <input type="text" name="english" placeholder="enter english"><br><br>
            <input type="text" name="math" placeholder="enter math"><br><br>
            <input type="text" name="php" placeholder="enter php"><br><br>
            <button name="send">Send</button>

        </form>
    </div>

</body>

</html>